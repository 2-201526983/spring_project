package com.hello.spring2.config.auth;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.hello.spring2.model.Member;

import lombok.Getter;

@Getter
public class PrincipalUser implements UserDetails,OAuth2User {
	private Member member;
	
	private Map<String, Object> attributes;
	
	public PrincipalUser(Member member) {
		this.member=member;
	}
	
	public PrincipalUser(Member member, Map<String, Object> attributes) {
		this.member=member;
		this.attributes=attributes;
	}
	
	
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Collection<GrantedAuthority>collect = new ArrayList<>();
		collect.add(()->{
			return member.getRole();
		});
		return collect;
	}
	@Override
	public String getPassword() {
		return member.getPassword();
	}
	@Override
	public String getUsername() {
		return member.getUsername();
	}
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	@Override
	public boolean isEnabled() {
		return true;
	}
	@Override
	public Map<String, Object> getAttributes() {
		
		
		// TODO Auto-generated method stub
		return attributes;
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
